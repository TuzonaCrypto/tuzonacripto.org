export const venezuelaStates = [
  "Amazonas", "Anzoátegui", "Apure", "Aragua", "Barinas", "Bolívar", 
  "Carabobo", "Cojedes", "Delta Amacuro", "Distrito Capital", "Falcón", 
  "Guárico", "Lara", "Mérida", "Miranda", "Monagas", "Nueva Esparta", 
  "Portuguesa", "Sucre", "Táchira", "Trujillo", "Vargas", "Yaracuy", "Zulia"
];

export const businessCategories = [
  "Restaurante", "Tecnología", "Salud", "Automotriz", "Moda", "Educación",
  "Servicios Financieros", "Entretenimiento", "Deportes", "Belleza",
  "Hogar y Jardín", "Mascotas", "Viajes", "Inmobiliaria", "Legal",
  "Hotel", "Agencia de Viajes", "Profesional", "Técnico"
];

export const cryptoCurrencies = [
  "Bitcoin", "Ethereum", "USDT", "Dash", "Litecoin", "Bitcoin Cash",
  "Monero", "Zcash", "Dogecoin", "Cardano", "Polkadot", "Chainlink"
];